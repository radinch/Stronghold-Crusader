package View;

import java.util.Scanner;

public class ProfileMenu {
    public void run(Scanner scanner){

    }
}
