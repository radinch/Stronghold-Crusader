package Controller;

import Model.gameandbattle.Government;
import Model.gameandbattle.map.Map;

import java.util.regex.Matcher;

public class UnitMenuController {
    Government government;
    Map map;
    public String selectUnit(Matcher matcher){
        return null;
    }
    public String moveUnit(Matcher matcher){
        return null;
    }
    public String setCondition(Matcher matcher){
        return null;
    }
    public String attack(Matcher matcher){
        return  null;
    }
    public String skyAttack(Matcher matcher){
        return null;
    }
    public String pourOil(Matcher matcher){
        return null;
    }
    public String digTunnel(Matcher matcher) {
        return null;

    }
    public String buildSurroundings(Matcher matcher){
        return null;
    }
    public String disbandUnit(Matcher matcher){
        return null;
    }
}
