package Model.buildings;

import Model.gameandbattle.map.Building;
import Model.gameandbattle.Government;
import Model.gameandbattle.map.Cell;
import Model.gameandbattle.map.Map;
import Model.gameandbattle.map.Texture;
import Model.gameandbattle.stockpile.Resource;

import java.util.ArrayList;
import java.util.Scanner;

public class OtherBuilding extends Building {
    private Integer rate;
    private Integer capacity;


    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public OtherBuilding(Government government, double gold, String name, int hitpoint, Resource resourceRequired, int amountOfResource, int amountOfWorkers, ArrayList<Texture> textures, Cell occupiedCell, Integer rate, Integer capacity) {
        super(government, gold, name, hitpoint, resourceRequired,amountOfResource, amountOfWorkers,textures,occupiedCell);
        this.rate = rate;
        this.capacity = capacity;
    }

    @Override
    public void whenBuildingIsSelected(int x, int y, Map map, Scanner scanner) {
        super.whenBuildingIsSelected(x, y, map,scanner);
    }

    @Override
    public void makeAffect(int x, int y, Map map) {
        super.makeAffect(x, y, map);
        extract();
    }

    private void extract()
    {
        //todo get tree for woodcutter
        switch (getName()) {
            case "Iron mine" ->
                    this.getGovernment().getStockpile().setMetal(this.getGovernment().getStockpile().getMetal() + getRate());
            case "Quarry" ->
                    this.getGovernment().getStockpile().setStone(this.getGovernment().getStockpile().getStone() + getRate());
            case "Woodcutter" ->
                    this.getGovernment().getStockpile().setWood(this.getGovernment().getStockpile().getWood() + getRate());
            case "Apple garden" -> {
                this.getGovernment().getGranary().setApple(getGovernment().getGranary().getApple() + rate);
                getGovernment().getFoods()[2] += rate;
            }
            case "Hop garden" ->
                    this.getGovernment().getStockpile().setHops(getGovernment().getStockpile().getHops() + rate);
            case "Wheat garden" ->
                    this.getGovernment().getStockpile().setWheat(getGovernment().getStockpile().getWheat() + rate);
            case "Dairy products" -> {
                this.getGovernment().getGranary().setCheese(getGovernment().getGranary().getCheese() + rate);
                this.getGovernment().getWeapons()[6] +=rate;
                getGovernment().getFoods()[1] += rate;
            }
            case "hunting post" -> {
                this.getGovernment().getGranary().setMeat(getGovernment().getGranary().getMeat() + rate);
                getGovernment().getFoods()[0] += rate;
            }
            case "Pitch rig" -> {
                this.getGovernment().getStockpile().setPitch(getGovernment().getStockpile().getPitch() + rate);
            }
        }
    }

    private void processFood()
    {
        //todo maximum food and resource
        switch (getName()) {
            case "Mill" -> {
                if(this.getGovernment().getStockpile().getWheat() - getRate() >= 0) {
                    this.getGovernment().getStockpile().setFloor(this.getGovernment().getStockpile().getFloor() + getRate());
                    this.getGovernment().getStockpile().setWheat(this.getGovernment().getStockpile().getWheat() - getRate());
                }
            }
            case "Bakery" -> {
                if(this.getGovernment().getStockpile().getFloor() - getRate() >= 0) {
                    this.getGovernment().getGranary().setBread(this.getGovernment().getGranary().getBread() + getRate());
                    this.getGovernment().getFoods()[3] -= getRate();
                    this.getGovernment().getStockpile().setFloor(this.getGovernment().getStockpile().getFloor() - getRate());
                }
            }
            case "Brewery" -> {
                if(this.getGovernment().getStockpile().getHops() - getRate() >= 0) {
                    this.getGovernment().getStockpile().setAle(this.getGovernment().getStockpile().getAle() + getRate());
                    this.getGovernment().getStockpile().setHops(this.getGovernment().getStockpile().getHops() - getRate());
                }
            }
        }
    }
}
