package org.example;

public enum ClientType {
    WORKER,
    CLIENT,
    UNKNOWN,
}