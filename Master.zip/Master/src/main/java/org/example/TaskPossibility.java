package org.example;

public enum TaskPossibility {
    RUNNING,
    PENDING;
}
