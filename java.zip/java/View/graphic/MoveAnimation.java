package View.graphic;

import javafx.animation.Animation;
import javafx.animation.Transition;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.util.Duration;

import java.util.ArrayList;

public class MoveAnimation extends Transition {
    private HBox hbox;
    private ImageView imageView;

    public MoveAnimation(HBox hBox, ImageView imageView) {
        this.hbox = hBox;
        this.imageView = imageView;
        setCycleCount(-1);
        setCycleDuration(Duration.millis(500));
    }

    @Override
    protected void interpolate(double v) {
        Double x;
        Double y;
        x = hbox.getLayoutX();
        y = hbox.getLayoutY();
    }
}
