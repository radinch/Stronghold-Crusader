package controller;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;
import model.Ball;
import model.User;
import view.*;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import static view.Game.*;
import static view.ShootingAnimation.*;

public class GameController {
    private AudioClip shootingSound = new AudioClip(getClass().getResource("/images/shoot.wav").toString());
    private static final int TOTAL_SECONDS = 180;
    private Timeline timeline;
    private Text timerText;
    public int secondsElapsed;
    public TextField music;
    public static Label label;
    public static Label amountOfBallsLeft = new Label("Balls Left");
    public static Media sound;
    public static MediaPlayer mediaPlayer;
    public static ImageView cannon;
    public static ProgressBar bar = new ProgressBar(0);
    public static Color winOrLose = Color.ANTIQUEWHITE;


    public void shoot(Pane gamePane, Ball mainBall) {
        Ball ball = new Ball(10,mainBall.getX(),mainBall.getY());
        Game.balls.add(ball);
        gamePane.getChildren().add(ball);
        Label label = null;
        if(score < 3*totalBalls/4) {
            label = ShootingAnimation.makeLabel(ball);
        }
        new CannonAnimation(cannon).play();
        ShootingAnimation shootingAnimation = new ShootingAnimation(gamePane,ball, Game.stage,label);
        shootingAnimation.play();
    }
    public void shoot2(Pane gamePane)
    {
            Ball ball2 = new Ball(10, 300, 0);
            ball2.setFill(Color.RED);
            Game.balls.add(ball2);
            gamePane.getChildren().add(ball2);
            Shooting2 shooting2 = new Shooting2(gamePane,ball2, Game.stage,label);
            shooting2.play();
    }
    public Ball createBall(Pane gamePane) {
        Ball mainBall = new Ball(10,300,370);
        if(MainMenu.twoPlayer == 1)
        {
            Ball twoBall = new Ball(10,300,0);
        }
        mainBall.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                //todo
                String keyName = keyEvent.getCode().getName();
                if (keyName.equals(User.getAllUsers().get(LoginMenu.LoggedInUsername).getShootingKey())) {
                    shoot(gamePane, mainBall);
                    shootingSound.play();
                }
                if (keyName.equals("Tab")) {
                        if(score >= 10) {
                            new FreezeAnimation().play();
                            bar.setProgress(0);
                        }
                }
                if(keyName.equals("Enter"))
                {
                    shoot2(gamePane);
                    shootingSound.play();
                }
                if(keyName.equals(KeyCode.RIGHT.getName()))
                    moveRight(mainBall);
                if(keyName.equals(KeyCode.LEFT.getName()))
                    moveLeft(mainBall);
                if(keyName.equals(KeyCode.P.getName())) {
                    try {
                        pause();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
        return mainBall;
    }

    private void moveRight(Ball mainBall) {
        if(score >= 3*totalBalls/4) {
            if (mainBall.getX() + 10 < 500)
                mainBall.setX(mainBall.getX() + 10);
        }
    }
    private void moveLeft(Ball mainBall) {
        if(score >= 3*totalBalls/4) {
            if (mainBall.getX() - 10 > 100)
                mainBall.setX(mainBall.getX() - 10);
        }
    }

    public void initializeGame(Pane gamePane) throws IOException {
        balls.clear();
        lines.clear();
        labels.clear();
        score = 0;
        ImageView avatarPic = new ImageView();
        Ball lowBall = createBall(gamePane);

        avatarPic.setImage(User.getAllUsers().get(LoginMenu.LoggedInUsername).getAvatar().getImage());
        avatarPic.setFitHeight(60);
        avatarPic.setFitWidth(60);

        bar.setLayoutY(77);
        label = new Label(String.valueOf(score));
        label.setBackground(new Background(new BackgroundFill(Color.BLACK, null, null)));
        label.setLayoutX(290);
        label.setLayoutY(130);
        label.setTextFill(Color.WHITE);
        label.setFont(new Font("Arial",24));
        // creating the low ball and central ball and adding central to the list of balls and animation1

        Ball centralCircle = new Ball(60,300,150);
        balls.add(centralCircle);
        central = centralCircle;
        RotationAnimation1 temp = new RotationAnimation1(gamePane,centralCircle,null,null);

        timerText = new Text();
        timerText.setLayoutY(120);
        timerText.setFont(Font.font(24));
        timeline = new Timeline(
                new KeyFrame(Duration.seconds(1), event -> {
                    secondsElapsed++;
                    updateTimerText();
                })
        );
        timeline.setCycleCount(Timeline.INDEFINITE);
        startTimer();
        Image image = new Image(LoginMenu.class.getResource("/images/back.jpg").openStream());
        BackgroundImage background = new BackgroundImage(image,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

        amountOfBallsLeft = new Label(totalBalls+" Balls Left");
        amountOfBallsLeft.setBackground(new Background(new BackgroundFill(Color.RED, null, null)));
        amountOfBallsLeft.setLayoutX(0);
        amountOfBallsLeft.setLayoutY(160);
        amountOfBallsLeft.setTextFill(Color.WHITE);
        amountOfBallsLeft.setFont(new Font("Arial",14));

        gamePane.setBackground(new Background(background));
        gamePane.getChildren().add(avatarPic);
        gamePane.getChildren().add(bar);
        gamePane.getChildren().add(lowBall);
        gamePane.getChildren().add(centralCircle);
        gamePane.getChildren().add(GameController.label);
        gamePane.getChildren().add(timerText);
        gamePane.getChildren().add(amountOfBallsLeft);
        cannon = new ImageView();
        cannon.setImage(new Image(LoginMenu.class.getResource("/images/cannon.jpg").openStream()));
        cannon.setFitHeight(30);
        cannon.setFitWidth(30);
        cannon.setX(285);
        cannon.setY(370);
        gamePane.getChildren().add(cannon);
        if(User.getAllUsers().get(LoginMenu.LoggedInUsername).getMap() == 2)
            mapLevel2();
        else if(User.getAllUsers().get(LoginMenu.LoggedInUsername).getMap() == 3)
            mapLevel3();
    }


    private void startTimer() {
        secondsElapsed = 0;
        updateTimerText();
        timeline.play();
    }
    private void updateTimerText() {
        int minutes = secondsElapsed / 60;
        int seconds = secondsElapsed % 60;
        String timerString = String.format("%02d:%02d", minutes, seconds);
        timerText.setText(timerString);

        if (secondsElapsed >= TOTAL_SECONDS) {
            // Game over, stop the timer or perform any necessary actions
            timeline.stop();
        }
    }

    public static boolean intersect(ShootingAnimation shootingAnimation, Ball ball)
    {
        for (int i = 5; i < gamePane.getChildren().size()-1; i++) {
            if (gamePane.getChildren().get(i) != ball &&
                    gamePane.getChildren().get(i) instanceof Ball &&
                    ball.getBoundsInParent().intersects(gamePane.getChildren().get(i).getBoundsInParent())) {
                shootingAnimation.stop();

                try {
                    winOrLose = Color.RED;
                    score--;
                    User.getAllUsers().get(LoginMenu.LoggedInUsername).setScore(score *
                            User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness());
                    if(score* User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness() >
                            User.getAllUsers().get(LoginMenu.LoggedInUsername).getHighScore()) {
                        User.getAllUsers().get(LoginMenu.LoggedInUsername).setFinishedTime(gameController.secondsElapsed);
                        User.getAllUsers().get(LoginMenu.LoggedInUsername).setHighScore(score*
                                User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness());
                    }
                    ScoreBoard scoreBoard = new ScoreBoard();
                    scoreBoard.start(Game.stage);
                    return true;
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return false;
    }
    public static boolean intersect(Shooting2 shootingAnimation, Ball ball)
    {
        for (int i = 5; i < gamePane.getChildren().size()-1; i++) {
            if (gamePane.getChildren().get(i) != ball &&
                    gamePane.getChildren().get(i) instanceof Ball &&
                    ball.getBoundsInParent().intersects(gamePane.getChildren().get(i).getBoundsInParent())) {
                shootingAnimation.stop();

                try {
                    winOrLose = Color.RED;
                    score--;
                    User.getAllUsers().get(LoginMenu.LoggedInUsername).setScore(score *
                            User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness());
                    if(score* User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness() >
                            User.getAllUsers().get(LoginMenu.LoggedInUsername).getHighScore()) {
                        User.getAllUsers().get(LoginMenu.LoggedInUsername).setFinishedTime(gameController.secondsElapsed);
                        User.getAllUsers().get(LoginMenu.LoggedInUsername).setHighScore(score*
                                User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness());
                    }
                    ScoreBoard scoreBoard = new ScoreBoard();
                    scoreBoard.start(Game.stage);
                    return true;
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return false;
    }

    public static void phase2(int totalBalls, Ball ball, Line line,Label label)
    {
        if(Game.score == totalBalls/4 + 1) {
            RotationAnimation2 central = new RotationAnimation2(gamePane, Game.balls.get(0), null,null);
            for (RotationAnimation1 animation1 : animation1s) {
                animation1.stop();
            }
            for (int i = 1; i < balls.size()-1; i++) {
                if(MainMenu.twoPlayer == 0) {
                    RotationAnimation2 temp = new RotationAnimation2(gamePane, Game.balls.get(i), Game.lines.get(i - 1), labels.get(i - 1));
                    temp.setAngle(animation1s.get(i).getAngle());
                }
                else {
                    RotationAnimation2 temp = new RotationAnimation2(gamePane, Game.balls.get(i), Game.lines.get(i - 1), null);
                    temp.setAngle(animation1s.get(i).getAngle());
                }
            }
        }
        RotationAnimation2 temp = new RotationAnimation2(gamePane,ball,line,label);
    }
    public static void phase3()
    {
        for (int i = 1; i < balls.size(); i++) {
            VisibilityAnimation visibilityAnimation = new VisibilityAnimation(balls.get(i));
            visibilityAnimation.play();
        }
        for (int i = 0; i < lines.size(); i++) {
            VisibilityAnimation visibilityAnimation = new VisibilityAnimation(lines.get(i));
            visibilityAnimation.play();
        }
        for (int i = 0; i < labels.size(); i++) {
            VisibilityAnimation visibilityAnimation = new VisibilityAnimation(labels.get(i));
            visibilityAnimation.play();
        }
    }

    public static Color leftColor()
    {
        if((totalBalls - score) > 2*totalBalls/3)
        {
            return Color.RED;
        }
        else if((totalBalls - score) > totalBalls/3){
            return Color.YELLOW;
        }
        else {
            return Color.GREEN;
        }
    }

    public void mapLevel2()
    {
        Ball ball = new Ball(10,300,290);
        Game.balls.add(ball);
        gamePane.getChildren().add(ball);
        Label label1 = makeLabel(ball);
        ShootingAnimation shootingAnimation = new ShootingAnimation(gamePane,ball, Game.stage,label1);
        shootingAnimation.play();
        Ball ball2 = new Ball(10,170,150);
        Game.balls.add(ball2);
        gamePane.getChildren().add(ball2);
        Label label2 = makeLabel(ball2);
        ShootingAnimation shootingAnimation2 = new ShootingAnimation(gamePane,ball2, Game.stage,label2);
        shootingAnimation2.play();
        Ball ball3 = new Ball(10,430,150);
        Game.balls.add(ball3);
        gamePane.getChildren().add(ball3);
        Label label3 = makeLabel(ball3);
        ShootingAnimation shootingAnimation3 = new ShootingAnimation(gamePane,ball3, Game.stage,label3);
        shootingAnimation3.play();
        Ball ball4 = new Ball(10,300,25);
        Game.balls.add(ball4);
        gamePane.getChildren().add(ball4);
        Label label4 = makeLabel(ball4);
        ShootingAnimation shootingAnimation4 = new ShootingAnimation(gamePane,ball4, Game.stage,label4);
        shootingAnimation4.play();
        Ball ball5 = new Ball(10,210,60);
        Game.balls.add(ball5);
        gamePane.getChildren().add(ball5);
        Label label5 = makeLabel(ball5);
        ShootingAnimation shootingAnimation5 = new ShootingAnimation(gamePane,ball5, Game.stage,label5);
        shootingAnimation5.play();
        score-=5;
    }
    public void mapLevel3()
    {
        Ball ball = new Ball(10,200,70);
        Game.balls.add(ball);
        gamePane.getChildren().add(ball);
        Label label1 = makeLabel(ball);
        ShootingAnimation shootingAnimation = new ShootingAnimation(gamePane,ball, Game.stage,label1);
        shootingAnimation.play();
        Ball ball2 = new Ball(10,200,230);
        Game.balls.add(ball2);
        gamePane.getChildren().add(ball2);
        Label label2 = makeLabel(ball2);
        ShootingAnimation shootingAnimation2 = new ShootingAnimation(gamePane,ball2, Game.stage,label2);
        shootingAnimation2.play();
        Ball ball3 = new Ball(10,400,230);
        Game.balls.add(ball3);
        gamePane.getChildren().add(ball3);
        Label label3 = makeLabel(ball3);
        ShootingAnimation shootingAnimation3 = new ShootingAnimation(gamePane,ball3, Game.stage,label3);
        shootingAnimation3.play();
        Ball ball4 = new Ball(10,400,70);
        Game.balls.add(ball4);
        gamePane.getChildren().add(ball4);
        Label label4 = makeLabel(ball4);
        ShootingAnimation shootingAnimation4 = new ShootingAnimation(gamePane,ball4, Game.stage,label4);
        shootingAnimation4.play();
        score-=4;
    }
    public void pause() throws IOException {
        Pane pausePane = new Pane();
        pausePane = FXMLLoader.load(
                new URL(LoginMenu.class.getResource("/fxml/PauseMenu.fxml").toExternalForm()));
        Scene scene = new Scene(pausePane);
        Game.stage.setScene(scene);
    }

    public void saveGame(MouseEvent mouseEvent) {
        User.getAllUsers().get(LoginMenu.LoggedInUsername).setSavedGame(gameScene);
        Alert success = new Alert(Alert.AlertType.INFORMATION);
        success.setTitle("Done");
        success.setHeaderText("Success");
        success.setContentText("your game has been saved successfully");
        success.showAndWait();
    }

    public void Restart(MouseEvent mouseEvent) throws Exception {
        new Game().start(Game.stage);
    }

    public void changeMusic(MouseEvent mouseEvent) {
        LoginMenu.mediaPlayer.stop();
        mediaPlayer.stop();
        sound = new Media(Game.class.getResource("/images/music3.mp3").toString());
        switch (music.getText()){
            case "1":
                sound = new Media(Game.class.getResource("/images/music.mp3").toString());
                break;
            case "2":
                sound = new Media(Game.class.getResource("/images/music2.mp3").toString());
                break;
            case "3":
                sound = new Media(Game.class.getResource("/images/music3.mp3").toString());
                break;
        }
        mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
        mediaPlayer.play();
    }

    public void continueGame(MouseEvent mouseEvent) {
        Game.stage.setScene(gameScene);
    }

    public void mute(MouseEvent mouseEvent) {
        if(!LoginMenu.mediaPlayer.isMute()) {
            LoginMenu.mediaPlayer.setVolume(0.0);
            LoginMenu.mediaPlayer.setMute(true);
        }
        else {
            LoginMenu.mediaPlayer.setVolume(1.0);
            LoginMenu.mediaPlayer.setMute(false);
        }
    }

    public void exit(MouseEvent mouseEvent) throws Exception {
        new MainMenu().start(Game.stage);
    }

    public void Help(MouseEvent mouseEvent) {
        Alert success = new Alert(Alert.AlertType.CONFIRMATION);
        success.setTitle("Help");
        success.setHeaderText("Movements : ");
        success.setContentText("you can shoot balls with Space\nyou can move to right and left when with key arrows in phase 4" );
        success.showAndWait();
    }
    public static void phase4() {
        Random random = new Random();
        int randomAngle = random.nextInt(30)-15;
        Label labelAngle = new Label("Angle : " + String.valueOf(randomAngle));
        labelAngle.setTextFill(Color.LIMEGREEN);
        labelAngle.setLayoutY(200);
        gamePane.getChildren().add(labelAngle);
        ShootingAnimation.setAngle(randomAngle);
    }
}
