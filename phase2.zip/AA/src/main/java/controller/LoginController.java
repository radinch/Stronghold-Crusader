package controller;

import com.fasterxml.jackson.core.type.TypeReference;
import model.User;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.fasterxml.jackson.databind.ObjectMapper;

public class LoginController {
    public String username;
    public String password;

    public LoginController(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public boolean canLogin()
    {
        if(!User.getAllUsers().containsKey(username))
        {
            return false;
        }
        else if(!User.getAllUsers().get(username).getPassword().equals(password))
            return false;
        return true;
    }
//    public static ArrayList<User> readFromJson() {
//        File file = new File("users.json");
//        ObjectMapper objectMapper = new ObjectMapper();
//        if (file.length() != 0) {
//            try {
//                return objectMapper.readValue(file, new TypeReference<>() {
//                });
//            } catch (IOException e) {
//                e.printStackTrace();
//                return new ArrayList<>();
//            }
//        }
//        return new ArrayList<>();
//    }
//    public static void writeToJson(ArrayList<User> users) {
//        ObjectMapper objectMapper = new ObjectMapper();
//        try {
//            objectMapper.writeValue(new File("users.json"), users);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//    }
}
