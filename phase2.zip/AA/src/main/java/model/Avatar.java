package model;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.io.File;

public class Avatar extends Rectangle {
    private int picNumber = 100;
    private File file;
    public Avatar(int picNumber) {
        super(10, 10, 50, 50);
        this.picNumber = picNumber;
        this.setFill(new ImagePattern(
                new Image(Avatar.class.getResource("/images/"+picNumber+".jpg").toExternalForm())));
    }
    public Avatar(File file)
    {
        super(10, 10, 50, 50);
        this.file = file;
        this.setFill(new ImagePattern(
                new Image(file.getPath())));
    }
    public Image getImage()
    {
        if(picNumber != 100) {
            return new Image(Avatar.class.getResource("/images/" + picNumber + ".jpg").toExternalForm());
        }
        else {
            return new Image(file.getPath());
        }
    }
}
