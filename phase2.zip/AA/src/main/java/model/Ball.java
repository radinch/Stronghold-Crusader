package model;

import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

public class Ball extends Circle {
    private double radius;
    private double x;
    private double y;

    public Ball(double radius, double x, double y) {
        super(x, y, radius);
        this.radius = radius;
        this.x = x;
        this.y = y;
        this.setFill(Color.BLACK);
    }

    public double getX() {
        return getCenterX();
    }

    public double getY() {
        return getCenterY();
    }

    public void setX(double x) {
        setCenterX(x);
    }

    public void setY(double y) {
        setCenterY(y);
    }
}
