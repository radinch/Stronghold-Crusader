package model;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;

import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;

public class DataStorage {
    public static ArrayList<UserLogin> readFromJson() {
        File file = new File("users.json");
        ObjectMapper objectMapper = new ObjectMapper();
        if (file.length() != 0) {
            try {
                return objectMapper.readValue(file, new TypeReference<>() {
                });
            } catch (IOException e) {
                e.printStackTrace();
                return new ArrayList<>();
            }
        }
        return new ArrayList<>();
    }
    public static void writeToJson(ArrayList<UserLogin> users) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            objectMapper.writeValue(new File("users.json"), users);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}