package model;

public enum Difficulty {
    EASY(5,12,7),
    NORMAL(10,15,5),
    HARD(15,18,3);
    int rotationSpeed;
    int windSpeed;
    int frozenTime;
    Difficulty(int rotationSpeed,int windSpeed,int frozenTime)
    {
        this.rotationSpeed = rotationSpeed;
        this.windSpeed = windSpeed;
        this.frozenTime = frozenTime;
    }

    public int getFrozenTime() {
        return frozenTime;
    }

    public int getRotationSpeed() {
        return rotationSpeed;
    }

    public int getWindSpeed() {
        return windSpeed;
    }

    public int Hardness()
    {
        if(this.equals(Difficulty.EASY))
            return 1;
        else if(this.equals(Difficulty.NORMAL))
            return 2;
        else
            return 3;
    }
}
