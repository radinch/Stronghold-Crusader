package model;

import view.LoginMenu;

public enum Language {
    loginMenu("صفحه ورود","Login Menu"),
    signupMenu("صفحه ثبت نام","Sign up Menu"),
    enterAsGuest("ورود به عنوان مهمان", "Enter as a guest"),
    login("ورود", "Login"),
    dontHaveAccount("حساب کاربری ندارید؟ ثبت نام کنید", "Don't have an account? Sign up"),
    theLastOfBalls("آخرین توپ ها", "The Last of Balls"),
    password("گذرواژه", "Password"),
    signUp("ثبت نام", "Sign up"),
    goBackToLoginMenu("بازگشت به صفحه ورود", "Go back to login menu"),
    mainMenu("منوی اصلی", "Main menu"),
    newGame("بازی جدید", "New game"),
    continueGame("ادامه بازی", "Continue"),
    profileMenu("منوی پروفایل", "Profile menu"),
    scoreboard("جدول امتیازات", "Scoreboard"),
    settings("تنظیمات", "Settings"),
    exit("خروج", "Exit"),
    changeUsername("تغییر نام کاربری", "Change username"),
    changePassword("تغییر رمز عبور", "Change password"),
    logout("خروج از حساب", "Log out"),
    deleteAccount("حذف حساب کاربری", "Delete account"),
    changeAvatar("تغییر آواتار", "Change avatar"),
    chooseLevel("انتخاب سطح", "Choose level"),
    ballCount("تعداد توپ ها", "Ball count"),
    map("نقشه", "Map"),
    mute("بی صدا", "Mute"),
    changeShootingKey("تغییر کلید شلیک", "Change shooting key"),
    back("بازگشت", "Back");

    public String persian;
    public String english;

    Language(String persian, String english) {
        this.persian = persian;
        this.english = english;
    }

    public String getEnglish() {
        return english;
    }

    public String getPersian() {
        return persian;
    }

    public static String getText(Language language)
    {
        if(User.getAllUsers().get(LoginMenu.LoggedInUsername).getLanguage() == 0)
        {
            return language.getEnglish();
        }
        else {
            return language.getPersian();
        }
    }
}
