package model;

import javafx.scene.Scene;
import javafx.scene.layout.Pane;

import java.util.ArrayList;
import java.util.HashMap;

public class User {
    public static HashMap<String ,User> allUsers = new HashMap<>();
    private static ArrayList<User> scoreboard = new ArrayList<>();
    private String username;
    private String password;
    private Avatar avatar;
    private int score;
    private int highScore;
    private Difficulty difficulty;
    private int countOfBalls;
    private int map = 1;
    private Scene savedGame;
    private String shootingKey = "Space";
    private int finishedTime = 0;
    private int language = 0;
    public int black = 0;

    public User(String username, String password, Avatar avatar){
        this.username = username;
        this.password = password;
        this.avatar = avatar;
        this.score = 0;
        this.highScore = 0;
        this.difficulty = Difficulty.NORMAL;
        this.countOfBalls = 12;
        scoreboard.add(this);
        allUsers.put(username,this);
        //DataStorage.saveData(allUsers);
    }

    public static HashMap<String, User> getAllUsers() {
        return allUsers;
    }


    public String getPassword() {
        return password;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    public void changeUsername(String oldUsername,String newUsername)
    {
        User temp = allUsers.get(oldUsername);
        allUsers.remove(oldUsername);
        allUsers.put(newUsername,temp);
    }

    public Avatar getAvatar() {
        return avatar;
    }

    public void setAvatar(Avatar avatar) {
        this.avatar = avatar;
    }

    public int getScore() {
        return score;
    }

    public String getUsername() {
        return username;
    }

    public static ArrayList<User> getScoreboard() {
        for (int i = 0; i < scoreboard.size(); i++) {
            for (int j = 0; j < scoreboard.size(); j++) {
                if(scoreboard.get(i).getHighScore() > scoreboard.get(j).getHighScore())
                {
                    User temp = scoreboard.get(j);
                    User temp2 = scoreboard.get(i);
                    ArrayList<User> newArr = new ArrayList<>();
                    for (int k = 0; k < scoreboard.size(); k++) {
                        if(k == i)
                        {
                            newArr.add(temp);
                        }
                        else if(k == j)
                        {
                            newArr.add(temp2);
                        }
                        else {
                            newArr.add(scoreboard.get(k));
                        }
                    }
                    scoreboard = newArr;
                }
                else if(scoreboard.get(i).getHighScore() == scoreboard.get(j).getHighScore()
                        && scoreboard.get(i).getFinishedTime() < scoreboard.get(j).getFinishedTime())
                {
                    User temp = scoreboard.get(j);
                    User temp2 = scoreboard.get(i);
                    ArrayList<User> newArr = new ArrayList<>();
                    for (int k = 0; k < scoreboard.size(); k++) {
                        if(k == i)
                        {
                            newArr.add(temp);
                        }
                        else if(k == j)
                        {
                            newArr.add(temp2);
                        }
                        else {
                            newArr.add(scoreboard.get(k));
                        }
                    }
                    scoreboard = newArr;
                }
            }
        }
        return scoreboard;
    }

    public void setDifficulty(Difficulty difficulty) {
        this.difficulty = difficulty;
    }

    public void setCountOfBalls(int countOfBalls) {
        this.countOfBalls = countOfBalls;
    }

    public Difficulty getDifficulty() {
        return difficulty;
    }

    public int getCountOfBalls() {
        return countOfBalls;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setMap(int map) {
        this.map = map;
    }

    public int getMap() {
        return map;
    }

    public void setSavedGame(Scene savedGame) {
        this.savedGame = savedGame;
    }

    public Scene getSavedGame() {
        return savedGame;
    }

    public void setShootingKey(String shootingKey) {
        this.shootingKey = shootingKey;
    }

    public String getShootingKey() {
        return shootingKey;
    }

    public int getHighScore() {
        return highScore;
    }

    public void setHighScore(int highScore) {
        this.highScore = highScore;
    }

    public void setFinishedTime(int finishedTime) {
        this.finishedTime = finishedTime;
    }

    public int getFinishedTime() {
        return finishedTime;
    }

    public int getLanguage() {
        return language;
    }

    public void setLanguage(int language) {
        this.language = language;
    }

}
