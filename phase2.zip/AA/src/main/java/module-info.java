module gameAA {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;
    requires com.google.gson;
    requires javafx.graphics;
    requires com.fasterxml.jackson.databind;
    opens model to com.fasterxml.jackson.databind, com.google.gson, javafx.fxml;
    exports model;
    opens controller to com.fasterxml.jackson.databind, com.google.gson, javafx.fxml;
    exports controller;
    opens view to javafx.graphics,javafx.fxml, com.google.gson, com.fasterxml.jackson.databind;
    exports view;
}