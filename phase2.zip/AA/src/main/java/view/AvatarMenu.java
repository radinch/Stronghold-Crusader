package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.Avatar;
import model.User;
import javafx.stage.FileChooser;

import java.io.File;
import java.net.URL;

public class AvatarMenu extends Application {
    public TextField number;
    public static Stage stage;
    public static FileChooser fileChooser;
    @Override
    public void start(Stage stage) throws Exception {
        fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("JPG Files", "*.jpg")
                ,new FileChooser.ExtensionFilter("PNG Files", "*.png")
        );
        Avatar avatar1 = new Avatar(1);
        avatar1.setX(10);
        avatar1.setY(30);
        Avatar avatar2 = new Avatar(2);
        avatar2.setX(160);
        avatar2.setY(30);
        Avatar avatar3 = new Avatar(3);
        avatar3.setX(310);
        avatar3.setY(30);
        Avatar avatar4 = new Avatar(4);
        avatar4.setX(460);
        avatar4.setY(30);
        AvatarMenu.stage = stage;
        BorderPane profilePane = FXMLLoader.load(
                new URL(LoginMenu.class.getResource("/fxml/AvatarMenu.fxml").toExternalForm()));
        profilePane.setBackground(new Background(new BackgroundFill(Color.ANTIQUEWHITE, null, null)));
        profilePane.getChildren().add(avatar1);
        profilePane.getChildren().add(avatar2);
        profilePane.getChildren().add(avatar3);
        profilePane.getChildren().add(avatar4);
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setSaturation(User.getAllUsers().get(LoginMenu.LoggedInUsername).black); // Set saturation to -1 to remove color
        profilePane.setEffect(colorAdjust);
        Scene scene = new Scene(profilePane);
        stage.setScene(scene);
        stage.show();
    }

    public void chooseAvatar(MouseEvent mouseEvent) throws Exception {
        Avatar avatar = new Avatar(Integer.parseInt(number.getText()));
        User.getAllUsers().get(LoginMenu.LoggedInUsername).setAvatar(avatar);
        new ProfileMenu().start(stage);
    }

    public void chooseFile(MouseEvent mouseEvent) throws Exception {
        File selectedFile = fileChooser.showOpenDialog(stage);
        Avatar avatar = new Avatar(selectedFile);
        User.getAllUsers().get(LoginMenu.LoggedInUsername).setAvatar(avatar);
        new ProfileMenu().start(stage);
    }
}
