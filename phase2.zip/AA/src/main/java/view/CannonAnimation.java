package view;

import javafx.animation.Interpolator;
import javafx.animation.Transition;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class CannonAnimation extends Transition {
    public static ImageView cannon;
    public CannonAnimation(ImageView cannon)
    {
        this.cannon = cannon;
        this.setCycleDuration(Duration.millis(500));
        this.setCycleCount(1);
        this.setInterpolator(Interpolator.LINEAR);
    }
    @Override
    protected void interpolate(double v) {
        double y = cannon.getY();
        if(v <= 0.5)
            cannon.setY(y+0.4);
        else
            cannon.setY(y - 0.4);
    }
}
