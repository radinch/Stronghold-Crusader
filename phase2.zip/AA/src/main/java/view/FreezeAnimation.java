package view;

import javafx.animation.Transition;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import model.Ball;
import model.User;

public class FreezeAnimation extends Transition {
    public FreezeAnimation()
    {
        for (Ball ball : Game.balls) {
            ball.setFill(Color.LIGHTBLUE);
        }
        this.setCycleDuration(Duration.seconds(User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().getFrozenTime()));
        this.setCycleCount(1);
    }
    @Override
    protected void interpolate(double v) {
        for (RotationAnimation2 animation2 : ShootingAnimation.animation2s) {
            animation2.setRate(0.001);
        }
        if(v == 1)
        {
            for (RotationAnimation2 animation2 : ShootingAnimation.animation2s) {
                animation2.setRate(1);
            }
            for (Ball ball : Game.balls) {
                ball.setFill(Color.BLACK);
            }
        }
    }
}
