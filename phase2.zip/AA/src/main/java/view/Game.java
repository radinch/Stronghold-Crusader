package view;

import controller.GameController;
import javafx.animation.Animation;
import javafx.animation.RotateTransition;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.Ball;
import model.User;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;

public class Game extends Application {
    public static Stage stage;
    public static Scene gameScene;
    public static GameController gameController = new GameController();
    public static ArrayList<Ball> balls = new ArrayList<>();
    public static ArrayList<Line> lines = new ArrayList<>();
    public static ArrayList<Label> labels = new ArrayList<>();
    public static Ball central;
    public static int score = 0;
    public static Pane gamePane;

    @Override
    public void start(Stage stage) throws Exception {
        Game.stage = stage;
        gamePane = FXMLLoader.load(
                new URL(LoginMenu.class.getResource("/fxml/Game.fxml").toExternalForm()));
        gameController.initializeGame(gamePane);
        Scene scene = new Scene(gamePane);
        stage.setScene(scene);
        gamePane.getChildren().get(3).requestFocus();
        gameScene = scene;
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setSaturation(User.getAllUsers().get(LoginMenu.LoggedInUsername).black); // Set saturation to -1 to remove color
        gamePane.setEffect(colorAdjust);
        stage.show();
    }

    public void start(Scene scene) throws Exception {
        gamePane = FXMLLoader.load(
                new URL(LoginMenu.class.getResource("/fxml/Game.fxml").toExternalForm()));
        stage.setScene(scene);
        gameScene = scene;
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setSaturation(User.getAllUsers().get(LoginMenu.LoggedInUsername).black); // Set saturation to -1 to remove color
        gamePane.setEffect(colorAdjust);
        stage.show();
    }

}
