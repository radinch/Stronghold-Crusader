package view;

import controller.LoginController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.LinearGradient;
import javafx.stage.Popup;
import javafx.stage.Stage;
import model.Avatar;
import model.User;

import java.lang.reflect.Array;
import java.net.URL;
import java.util.ArrayList;

public class LoginMenu extends Application {
    public static String LoggedInUsername;
    public Label label;
    public TextField username;
    public PasswordField password;
    public static Stage stage;
    public static Media sound = new Media(Game.class.getResource("/images/music3.mp3").toString());
    public static MediaPlayer mediaPlayer = new MediaPlayer(sound);
    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) throws Exception {
        LoginMenu.stage = stage;
        BorderPane loginPane = FXMLLoader.load(
                new URL(LoginMenu.class.getResource("/fxml/LoginMenu.fxml").toExternalForm()));
        Image image = new Image(LoginMenu.class.getResource("/images/backMain.jpg").openStream());
        BackgroundImage background = new BackgroundImage(image,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        loginPane.setBackground(new Background(background));
        Scene scene = new Scene(loginPane);
        stage.setScene(scene);
        mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
        mediaPlayer.play();
        stage.getIcons().add(new Image(LoginMenu.class.getResource("/images/aaIcon.png").openStream()));
        stage.show();
    }

    public void Login(MouseEvent mouseEvent) throws Exception {
        LoginMenu.LoggedInUsername = username.getText();
        LoginController loginController = new LoginController(username.getText(),password.getText());
        if(loginController.canLogin()){
            new MainMenu().start(stage);
        }
        else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error");
            alert.setHeaderText("Failed");
            alert.setContentText("the username or password is incorrect");
            alert.showAndWait();
        }
    }

    public void signup(MouseEvent mouseEvent) throws Exception {
        new SignupMenu().start(stage);
    }

    public void guest(MouseEvent mouseEvent) throws Exception {
        User user = new User("guest","123456",new Avatar(1));
        LoggedInUsername = "guest";
        new MainMenu().start(stage);
    }
}
