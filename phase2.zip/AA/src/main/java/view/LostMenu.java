package view;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import model.User;

import java.net.URL;
import java.util.concurrent.Callable;

public class LostMenu extends Application {
    public static Stage stage;
    @Override
    public void start(Stage stage) throws Exception {
        Label label = new Label("YOU LOST");
        label.setLayoutX(250);
        label.setLayoutY(100);
        label.fontProperty().set(new Font(20));
        LostMenu.stage = stage;
        Button retry = new Button("Retry");
        retry.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new Game().start(stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        Button exit = new Button("exit");
        exit.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new MainMenu().start(stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        retry.setLayoutX(170);
        retry.setLayoutY(300);
        exit.setLayoutX(370);
        exit.setLayoutY(300);
        Pane signupPane = FXMLLoader.load(
                new URL(LoginMenu.class.getResource("/fxml/ScoreBoard.fxml").toExternalForm()));
        signupPane.setBackground(new Background(new BackgroundFill(Color.RED, null, null)));
        signupPane.getChildren().add(retry);
        signupPane.getChildren().add(exit);
        signupPane.getChildren().add(label);
        Scene scene = new Scene(signupPane);
        stage.setScene(scene);
//        for (Node child : Game.gamePane.getChildren()) {
//            System.out.println(child);
//        }
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setSaturation(User.getAllUsers().get(LoginMenu.LoggedInUsername).black); // Set saturation to -1 to remove color
        signupPane.setEffect(colorAdjust);
        stage.show();
    }
}
