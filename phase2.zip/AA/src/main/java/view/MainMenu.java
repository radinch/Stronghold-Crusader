package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.User;

import java.net.URL;

public class MainMenu extends Application {
    public static Stage stage;
    public Label label;
    public static int twoPlayer = 0;
    @Override
    public void start(Stage stage) throws Exception {
        MainMenu.stage = stage;
        BorderPane mainMenu = FXMLLoader.load(
                new URL(LoginMenu.class.getResource("/fxml/MainMenu.fxml").toExternalForm()));
        Image image = new Image(LoginMenu.class.getResource("/images/backMain.jpg").openStream());
        BackgroundImage background = new BackgroundImage(image,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        mainMenu.setBackground(new Background(background));
        mainMenu.getChildren().add(User.getAllUsers().get(LoginMenu.LoggedInUsername).getAvatar());
        Scene scene = new Scene(mainMenu);
        stage.setScene(scene);
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setSaturation(User.getAllUsers().get(LoginMenu.LoggedInUsername).black); // Set saturation to -1 to remove color
        mainMenu.setEffect(colorAdjust);
        stage.show();
    }

    public void Continue(MouseEvent mouseEvent) throws Exception {
        new Game().start(User.getAllUsers().get(LoginMenu.LoggedInUsername).getSavedGame());
    }

    public void startNewGame(MouseEvent mouseEvent) throws Exception {
        new Game().start(stage);
    }

    public void ProfileMenu(MouseEvent mouseEvent) throws Exception {
        new ProfileMenu().start(stage);
    }

    public void ScoreBoard(MouseEvent mouseEvent) throws Exception {
        new ScoreBoard().start(stage);
    }

    public void Settings(MouseEvent mouseEvent) throws Exception {
        new Settings().start(stage);
    }

    public void Exit(MouseEvent mouseEvent) {
        System.exit(0);
    }

    public void twoPlayer(MouseEvent mouseEvent) throws Exception {
        twoPlayer = 1;
        new Game().start(stage);
    }
}
