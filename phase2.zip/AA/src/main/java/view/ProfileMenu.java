package view;

import javafx.animation.StrokeTransition;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.User;

import java.net.URL;

public class ProfileMenu extends Application {
    public static Stage stage;
    public Label label;
    public TextField username;
    public PasswordField password;
    public void changeUsername(MouseEvent mouseEvent) throws Exception {
        if(User.getAllUsers().containsKey(username.getText()))
        {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error");
            alert.setHeaderText("Failed");
            alert.setContentText("this username already exist");
            alert.showAndWait();
        }
        else {
            User.getAllUsers().get(LoginMenu.LoggedInUsername).changeUsername(LoginMenu.LoggedInUsername,username.getText());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done");
            alert.setHeaderText("your username successfully changed to "+username.getText());
            alert.setContentText("you have to log in again");
            alert.showAndWait();
            new LoginMenu().start(stage);
        }
    }

    public void changePassword(MouseEvent mouseEvent) throws Exception {
        if(password.getText().length() < 6)
        {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error");
            alert.setHeaderText("Failed");
            alert.setContentText("this password is too short");
            alert.showAndWait();
        }
        else {
            User.getAllUsers().get(LoginMenu.LoggedInUsername).setPassword(password.getText());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done");
            alert.setHeaderText("your password successfully changed");
            alert.setContentText("you have to log in again");
            alert.showAndWait();
            new LoginMenu().start(stage);
        }
    }

    public void logout(MouseEvent mouseEvent) throws Exception {
        new LoginMenu().start(stage);
    }

    public void deleteAccount(MouseEvent mouseEvent) throws Exception {
        User.getAllUsers().remove(LoginMenu.LoggedInUsername);
        new LoginMenu().start(stage);
    }

    public void changeAvatar(MouseEvent mouseEvent) throws Exception {
        new AvatarMenu().start(stage);
    }

    @Override
    public void start(Stage stage) throws Exception {
        ProfileMenu.stage = stage;
        BorderPane profilePane = FXMLLoader.load(
                new URL(LoginMenu.class.getResource("/fxml/ProfileMenu.fxml").toExternalForm()));
        profilePane.setBackground(new Background(new BackgroundFill(Color.ANTIQUEWHITE, null, null)));
        profilePane.getChildren().add(User.getAllUsers().get(LoginMenu.LoggedInUsername).getAvatar());
        Scene scene = new Scene(profilePane);
        stage.setScene(scene);
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setSaturation(User.getAllUsers().get(LoginMenu.LoggedInUsername).black); // Set saturation to -1 to remove color
        profilePane.setEffect(colorAdjust);
        stage.show();
    }
}
