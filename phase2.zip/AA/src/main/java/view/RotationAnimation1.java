package view;

import javafx.animation.Interpolator;
import javafx.animation.Transition;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;
import model.Ball;
import model.User;

public class RotationAnimation1 extends Transition {
    private Pane pane;
    private Ball ball;
    private Line line;
    private Label label;
    public double angle;
    public RotationAnimation1(Pane pane, Ball ball, Line line,Label label) {
        this.pane = pane;
        this.ball = ball;
        this.line = line;
        this.label = label;
        double duration =(1.0 / (double) User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().getRotationSpeed()) * 30.0;
        this.setCycleDuration(Duration.seconds(duration));
        this.setCycleCount(-1);
        this.setInterpolator(Interpolator.LINEAR);
        ShootingAnimation.animation1s.add(this);
        this.play();
    }

    @Override
    protected void interpolate(double v) {
        angle = v * 360;
        Rotate rotation = new Rotate(angle, 300, 150); // Create the rotation transformation
        ball.getTransforms().setAll(rotation);
        if(line != null)
            line.getTransforms().setAll(rotation);
        if(label != null) {
            Rotate rotate = new Rotate(angle,-13,-103);
            label.getTransforms().setAll(rotate);
        }
    }

    public double getAngle() {
        return angle;
    }
}
