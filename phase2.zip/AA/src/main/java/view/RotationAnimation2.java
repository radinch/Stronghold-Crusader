package view;

import controller.GameController;
import javafx.animation.Interpolator;
import javafx.animation.Transition;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;
import model.Ball;
import model.User;

public class RotationAnimation2 extends Transition {
    private Pane pane;
    private Line line;
    private Ball ball;
    private Label label;
    public static double time;
    public double angle;
    public double speed = 1.6;
    public int cnt = 0;

    public RotationAnimation2(Pane pane, Ball ball, Line line, Label label) {
        this.pane = pane;
        this.ball = ball;
        this.line = line;
        this.label = label;
        double duration =(2.0 / (double) User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().getRotationSpeed()) * 30.0;
        this.setCycleDuration(Duration.seconds(duration));
        this.setCycleCount(-1);
        this.setInterpolator(Interpolator.LINEAR);
        ShootingAnimation.animation2s.add(this);
        this.play();
    }
    @Override
    protected void interpolate(double v) {
        if(ball == Game.central)
        {
            time = v;
        }
        if(time <= 0.5) {
            angle += speed; // Calculate the angle based on the interpolation value
            Rotate rotation = new Rotate(angle, 300, 150); // Create the rotation transformation
            Rotate rotate = new Rotate(angle,-13,-103);
            ball.getTransforms().setAll(rotation);
            if(ball != Game.central && Game.balls.indexOf(ball) >= 1+ShootingAnimation.totalBalls/4) {
                ball.setRadius(ball.getRadius() * 1.0007);
                if(MainMenu.twoPlayer == 0) {
                    if (GameController.intersect(ShootingAnimation.shootingAnimation, ball)) {
                        this.stop();
                    }
                }
            }
            if(line != null)
                line.getTransforms().setAll(rotation);
            if(label != null)
                label.getTransforms().setAll(rotate);
        }
        else {
            angle -= speed; // Calculate the angle based on the interpolation value
            Rotate rotation = new Rotate(angle, 300, 150); // Create the rotation transformation
            Rotate rotate = new Rotate(angle,-13,-103);
            ball.getTransforms().setAll(rotation);
            if(ball != Game.central && Game.balls.indexOf(ball) >= 1+ShootingAnimation.totalBalls/4) {
                ball.setRadius(ball.getRadius() / 1.0007);
                if(MainMenu.twoPlayer == 0) {
                    if (GameController.intersect(ShootingAnimation.shootingAnimation, ball)) {
                        this.stop();
                    }
                }
            }
            if(line != null)
                line.getTransforms().setAll(rotation);
            if(label != null)
                label.getTransforms().setAll(rotate);
        }
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public double getSpeed() {
        return speed;
    }

    public void setAngle(double angle) {
        this.angle = angle;
    }
}
