package view;

import controller.GameController;
import javafx.application.Application;
import javafx.css.converter.LadderConverter;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.User;

import java.net.URL;

public class ScoreBoard extends Application {
    public static Stage stage;
    public static Pane pane;
    @Override
    public void start(Stage stage) throws Exception {
        ScoreBoard.stage = stage;
        pane = FXMLLoader.load(
                new URL(LoginMenu.class.getResource("/fxml/ScoreBoard.fxml").toExternalForm()));
        pane.setBackground(new Background(new BackgroundFill(GameController.winOrLose, null, null)));
        GameController.winOrLose = Color.ANTIQUEWHITE;
        Button back = new Button("Back");
        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new MainMenu().start(stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        pane.getChildren().add(back);
        int cnt = 0;
        for (User user : User.getScoreboard()) {
            Label name = new Label(user.getUsername());
            Label score = new Label(String.valueOf(user.getHighScore()));
            Label time = new Label(String.valueOf(user.getFinishedTime()));
            name.setLayoutX(100);
            score.setLayoutX(200);
            time.setLayoutX(300);
            name.setLayoutY(cnt*40 + 100);
            score.setLayoutY(cnt*40 + 100);
            time.setLayoutY(40*cnt + 100);
            if(cnt == 0)
            {
                name.setBackground(Background.fill(Color.GOLD));
                score.setBackground(Background.fill(Color.GOLD));
                time.setBackground(Background.fill(Color.GOLD));
            }
            if(cnt == 1)
            {
                name.setBackground(Background.fill(Color.SILVER));
                score.setBackground(Background.fill(Color.SILVER));
                time.setBackground(Background.fill(Color.SILVER));
            }
            if(cnt == 2)
            {
                name.setBackground(Background.fill(Color.ORANGERED));
                score.setBackground(Background.fill(Color.ORANGERED));
                time.setBackground(Background.fill(Color.ORANGERED));
            }
            cnt++;
            pane.getChildren().add(name);
            pane.getChildren().add(score);
            pane.getChildren().add(time);
            if(cnt == 10)
                break;
        }
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setSaturation(User.getAllUsers().get(LoginMenu.LoggedInUsername).black); // Set saturation to -1 to remove color
        pane.setEffect(colorAdjust);
        stage.show();
    }

}
