package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.Difficulty;
import model.User;

import java.net.URL;

public class Settings extends Application {
    public static Stage stage;
    public Label label;
    public TextField level;
    public TextField ballCount;
    public TextField map;
    @Override
    public void start(Stage stage) throws Exception {
        Settings.stage = stage;
        BorderPane mainMenu = FXMLLoader.load(
                new URL(LoginMenu.class.getResource("/fxml/Settings.fxml").toExternalForm()));
        mainMenu.setBackground(new Background(new BackgroundFill(Color.ANTIQUEWHITE, null, null)));
        mainMenu.getChildren().add(User.getAllUsers().get(LoginMenu.LoggedInUsername).getAvatar());
        Scene scene = new Scene(mainMenu);
        stage.setScene(scene);
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setSaturation(User.getAllUsers().get(LoginMenu.LoggedInUsername).black); // Set saturation to -1 to remove color
        mainMenu.setEffect(colorAdjust);
        stage.show();
    }
    public void chooseLevel(MouseEvent mouseEvent) {
        boolean ok = true;
        if(level.getText().equals("1")){
            User.getAllUsers().get(LoginMenu.LoggedInUsername).setDifficulty(Difficulty.EASY);
        }
        else if(level.getText().equals("2")){
            User.getAllUsers().get(LoginMenu.LoggedInUsername).setDifficulty(Difficulty.NORMAL);
        }
        else if(level.getText().equals("3")){
            User.getAllUsers().get(LoginMenu.LoggedInUsername).setDifficulty(Difficulty.HARD);
        }
        else {
            ok = false;
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error");
            alert.setHeaderText("Failed");
            alert.setContentText("Invalid choose between 1,2,3");
            alert.showAndWait();
        }
        if(ok){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done");
            alert.setHeaderText("Success");
            alert.setContentText("your level has changed to "+ level.getText());
            alert.showAndWait();
        }
    }

    public void ballCount(MouseEvent mouseEvent) {
        User.getAllUsers().get(LoginMenu.LoggedInUsername).setCountOfBalls(Integer.parseInt(ballCount.getText()));
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done");
        alert.setHeaderText("Success");
        alert.setContentText("your Ball count has changed to "+ ballCount.getText());
        alert.showAndWait();
    }

    public void mute(MouseEvent mouseEvent) {
        if(!LoginMenu.mediaPlayer.isMute()) {
            LoginMenu.mediaPlayer.setVolume(0.0);
            LoginMenu.mediaPlayer.setMute(true);
        }
        else {
            LoginMenu.mediaPlayer.setVolume(1.0);
            LoginMenu.mediaPlayer.setMute(false);
        }
    }

    public void blackWhite(MouseEvent mouseEvent) {
        User.getAllUsers().get(LoginMenu.LoggedInUsername).black = -1;
    }

    public void language(MouseEvent mouseEvent) {
    }

    public void Back(MouseEvent mouseEvent) throws Exception {
        new MainMenu().start(stage);
    }

    public void map(MouseEvent mouseEvent) {
        User.getAllUsers().get(LoginMenu.LoggedInUsername).setMap(Integer.parseInt(map.getText()));
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Done");
        alert.setHeaderText("Success");
        alert.setContentText("Map changed Successfully");
        alert.showAndWait();
    }

    public void changeShoot(MouseEvent mouseEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Attention !");
        alert.setHeaderText("Change shooting Key");
        alert.setContentText("you have to click okay then press a Key");
        alert.showAndWait();
        if (alert.getResult() == ButtonType.OK) {
            Node sourceNode = (Node) mouseEvent.getSource();
            Scene scene = sourceNode.getScene();
            scene.setOnKeyPressed(event -> {
                KeyCode pressedKey = event.getCode();
                String keyName = pressedKey.getName();
                User.getAllUsers().get(LoginMenu.LoggedInUsername).setShootingKey(keyName);
                // You can perform any further actions with the pressed key here
            });
        }
    }
}
