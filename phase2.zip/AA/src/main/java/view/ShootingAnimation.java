package view;

import controller.GameController;
import javafx.animation.*;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.Ball;
import model.Difficulty;
import model.User;

import java.util.ArrayList;

import static view.Game.*;

public class ShootingAnimation extends Transition {
    public static ArrayList<RotationAnimation1> animation1s = new ArrayList<>();
    public static ArrayList<RotationAnimation2> animation2s = new ArrayList<>();
    public static Stage stage;
    private Pane pane;
    private Difficulty difficulty = User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty();
    public static int totalBalls = User.getAllUsers().get(LoginMenu.LoggedInUsername).getCountOfBalls();
    private Ball ball;
    public static ShootingAnimation shootingAnimation;
    public Label label;
    public static double angle;

    public ShootingAnimation(Pane pane, Ball ball, Stage stage, Label label) {
        ShootingAnimation.stage = stage;
        this.pane = pane;
        this.ball = ball;
        this.label = label;
        this.setCycleDuration(Duration.millis(1000));
        this.setCycleCount(-1);
        shootingAnimation = this;
    }

    @Override
    protected void interpolate(double v) {
        double y = ball.getY() - 10;
        angle = User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().getWindSpeed()/5;
        double x = ball.getX() - Math.tan(angle) * 10;
        double distance = Math.sqrt((Math.pow((central.getCenterX()-ball.getCenterX()),2) + Math.pow((central.getCenterY()-ball.getCenterY()),2)));
        if (distance <= 130) {
            Line line = makeLine(ball.getCenterX(),300,ball.getCenterY()-10,150);

            Game.score++;
            GameController.label.setText(String.valueOf(Game.score));
            GameController.amountOfBallsLeft.setText(String.valueOf(User.getAllUsers().get(LoginMenu.LoggedInUsername)
                    .getCountOfBalls() - score) + " Balls Left");
            GameController.amountOfBallsLeft.setBackground(new Background(new BackgroundFill(
                    GameController.leftColor(), null, null)));
            GameController.bar.setProgress((double) Game.score/10);
            if(score == totalBalls)
            {
                this.stop();
                try {
                    GameController.winOrLose = Color.GREEN;
                    score--;
                    User.getAllUsers().get(LoginMenu.LoggedInUsername).setScore(score
                            * User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness());
                    if(score * User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness()>
                            User.getAllUsers().get(LoginMenu.LoggedInUsername).getHighScore()) {
                        User.getAllUsers().get(LoginMenu.LoggedInUsername).setFinishedTime(gameController.secondsElapsed);
                        User.getAllUsers().get(LoginMenu.LoggedInUsername).setHighScore(score*
                                User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness());
                    }
                    new ScoreBoard().start(stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
            if(Game.score >= 3*totalBalls/4){
                GameController.phase4();
            }
            if(Game.score > totalBalls/2)
            {
                GameController.phase3();
            }
            if(Game.score > totalBalls/4)
            {
                GameController.phase2(totalBalls, ball, line,label);
            }
            else {
                new RotationAnimation1(pane, ball, line,label);
            }
            this.stop();
        }
        if(distance > 300)
        {
            this.stop();
            try {
                GameController.winOrLose = Color.RED;
                score--;
                User.getAllUsers().get(LoginMenu.LoggedInUsername).setScore(score *
                        User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness());
                if(score* User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness() >
                        User.getAllUsers().get(LoginMenu.LoggedInUsername).getHighScore()) {
                    User.getAllUsers().get(LoginMenu.LoggedInUsername).setFinishedTime(gameController.secondsElapsed);
                    User.getAllUsers().get(LoginMenu.LoggedInUsername).setHighScore(score*
                            User.getAllUsers().get(LoginMenu.LoggedInUsername).getDifficulty().Hardness());
                }
                ScoreBoard scoreBoard = new ScoreBoard();
                scoreBoard.start(Game.stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        if(GameController.intersect(this,ball))
        {
            this.stop();
        }
        ball.setY(y);
        ball.setX(x);
        if(label != null) {
            label.setLayoutY(y - 10);
            label.setLayoutX(x);
        }
    }
    public Line makeLine(double startX,double endX,double startY,double endY)
    {
        Line line = new Line();
        line.setStartX(startX);
        line.setEndX(endX);
        line.setStartY(startY);
        line.setEndY(endY);
        pane.getChildren().add(line);
        Game.lines.add(line);
        return line;
    }

    public static Label makeLabel(Ball ball)
    {
        if(MainMenu.twoPlayer == 0) {
            Label label = new Label(String.valueOf(totalBalls - score));
            label.setLayoutX(ball.getLayoutX());
            label.setLayoutY(ball.getLayoutY());
            label.setTextFill(Color.WHITE);
            labels.add(label);
            gamePane.getChildren().add(label);
            return label;
        }
        return null;
    }

    public static void setAngle(double angle) {
        ShootingAnimation.angle += angle;
    }
}

