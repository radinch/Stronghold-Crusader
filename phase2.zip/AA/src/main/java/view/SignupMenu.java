package view;

import controller.LoginController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.Avatar;
import model.User;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Random;

public class SignupMenu extends Application {
    public static Stage stage;
    public Label label;
    public TextField username;
    public PasswordField password;

    public void signup(MouseEvent mouseEvent) throws IOException {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Error");
        alert.setHeaderText("Failed");
        if(User.getAllUsers().containsKey(username.getText()))
        {
            alert.setContentText("the username already exist");
            alert.showAndWait();
        }
        else if(password.getText().length() < 6)
        {
            alert.setContentText("the password is too short");
            alert.showAndWait();
        }
        else {
            Random random = new Random();
            int rand = random.nextInt(4)+1;
            Avatar avatar = new Avatar(rand);
            User temp = new User(username.getText(),password.getText(),avatar);
            User.getAllUsers().put(username.getText(),temp);
            ArrayList<User> users = new ArrayList<>();
            users.add(temp);
//            LoginController.writeToJson(users);
            Alert success = new Alert(Alert.AlertType.INFORMATION);
            success.setTitle("Done");
            success.setHeaderText("Success");
            success.setContentText("you have signed up successfully");
            success.showAndWait();
        }
    }

    public void backToLogin(MouseEvent mouseEvent) throws Exception {
        new LoginMenu().start(stage);
    }

    @Override
    public void start(Stage stage) throws Exception {
        SignupMenu.stage = stage;
        BorderPane signupPane = FXMLLoader.load(
                new URL(LoginMenu.class.getResource("/fxml/signupMenu.fxml").toExternalForm()));
        Image image = new Image(LoginMenu.class.getResource("/images/backMain.jpg").openStream());
        BackgroundImage background = new BackgroundImage(image,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        signupPane.setBackground(new Background(background));
        Scene scene = new Scene(signupPane);
        stage.setScene(scene);
        stage.show();
    }
}
