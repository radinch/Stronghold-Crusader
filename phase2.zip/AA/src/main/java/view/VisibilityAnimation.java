package view;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.control.Label;
import javafx.scene.shape.Line;
import javafx.scene.shape.Shape;
import javafx.util.Duration;
import model.Ball;

public class VisibilityAnimation {
    private Ball ball;
    private Timeline timeline;
    private Line line;
    private Label label;

    public VisibilityAnimation(Ball ball) {
        this.ball = ball;
        this.timeline = new Timeline();

        // Set up keyframes for visibility animation
        KeyFrame visibleFrame = new KeyFrame(Duration.ZERO, new KeyValue(ball.visibleProperty(), true));
        KeyFrame invisibleFrame = new KeyFrame(Duration.seconds(1.5), new KeyValue(ball.visibleProperty(), false));
        KeyFrame visibleAgainFrame = new KeyFrame(Duration.seconds(3), new KeyValue(ball.visibleProperty(), true));

        // Add keyframes to the timeline
        timeline.getKeyFrames().addAll(visibleFrame, invisibleFrame, visibleAgainFrame);

        // Make the timeline loop indefinitely
        timeline.setCycleCount(Timeline.INDEFINITE);
    }
    public VisibilityAnimation(Line line) {
        this.line = line;
        this.timeline = new Timeline();

        // Set up keyframes for visibility animation
        KeyFrame visibleFrame = new KeyFrame(Duration.ZERO, new KeyValue(this.line.visibleProperty(), true));
        KeyFrame invisibleFrame = new KeyFrame(Duration.seconds(1.5), new KeyValue(this.line.visibleProperty(), false));
        KeyFrame visibleAgainFrame = new KeyFrame(Duration.seconds(3), new KeyValue(this.line.visibleProperty(), true));

        // Add keyframes to the timeline
        timeline.getKeyFrames().addAll(visibleFrame, invisibleFrame, visibleAgainFrame);

        // Make the timeline loop indefinitely
        timeline.setCycleCount(Timeline.INDEFINITE);
    }

    public VisibilityAnimation(Label label) {
        this.label = label;
        this.timeline = new Timeline();

        // Set up keyframes for visibility animation
        KeyFrame visibleFrame = new KeyFrame(Duration.ZERO, new KeyValue(this.label.visibleProperty(), true));
        KeyFrame invisibleFrame = new KeyFrame(Duration.seconds(1.5), new KeyValue(this.label.visibleProperty(), false));
        KeyFrame visibleAgainFrame = new KeyFrame(Duration.seconds(3), new KeyValue(this.label.visibleProperty(), true));

        // Add keyframes to the timeline
        timeline.getKeyFrames().addAll(visibleFrame, invisibleFrame, visibleAgainFrame);

        // Make the timeline loop indefinitely
        timeline.setCycleCount(Timeline.INDEFINITE);
    }

    public void play() {
        timeline.play();
    }

    public void stop() {
        timeline.stop();
    }
}
