package Model.buildings;

public enum BuildingDetails {
    // TODO: 4/12/2023 fill here

}
