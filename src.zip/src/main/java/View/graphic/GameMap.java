package View.graphic;
import Model.gameandbattle.map.Map;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
public class GameMap extends Application {
    int mapSize = 200;
    int viewSize = 10;
    int counter = 0;
    int rows = 200;
    int columns = 200;
    double cellWidth = 200;
    double cellHeight = 200;
    int ViewportTopLeftRow = 0;
    int ViewportTopLeftCol = 0;
    Image[][] cellImages;
    Stage stage;
    @FXML
    private ScrollPane scrollPane;
    @FXML
    private GridPane gridPane;
    @Override
    public void start(Stage primaryStage) {
        gridPane = new GridPane();
        scrollPane = new ScrollPane(gridPane);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setPannable(true);
        cellImages = new Image[rows][columns];
        for (int row = 0; row < 10; row++) {
            for (int col = 0; col < 10; col++) {
                // Create an ImageView and set the image for the cell
                cellImages[row][col] = new Image(Map.MAP_NUMBER_ONE.getACell(row,col).getTexture().getImageAddress());
                ImageView imageView = new ImageView(cellImages[row][col]);

                // Set any additional properties for the ImageView (e.g., size, fit)

                imageView.setFitWidth(cellWidth);

                imageView.setFitHeight(cellHeight);

                // Add the ImageView to the GridPane
                gridPane.add(imageView, col, row);
            }
        }
        scrollPane.setOnScroll(new EventHandler<ScrollEvent>() {
            @Override
            public void handle(ScrollEvent scrollEvent) {
                ViewportTopLeftRow = Math.min(200 - 10, ViewportTopLeftRow - (int)scrollEvent.getDeltaY()/10);
                ViewportTopLeftRow = Math.max(0,ViewportTopLeftRow);
                ViewportTopLeftCol = Math.min(200 - 10, ViewportTopLeftCol - (int)scrollEvent.getDeltaX()/10);
                ViewportTopLeftCol = Math.max(0,ViewportTopLeftCol);
                ShowMap();
            }
        });
        primaryStage.setFullScreen(true);
        primaryStage.setScene(new Scene(scrollPane));
        primaryStage.show();
    }
    public void ShowMap()
    {
        int startRow = ViewportTopLeftRow;
        int endRow = Math.min(startRow + 10, 200);
        int startCol = ViewportTopLeftCol;
        int endCol = Math.min(startCol + 10, 200);
        gridPane.getChildren().clear();
        for (int row = startRow; row < endRow; row++) {
            for (int col = startCol; col < endCol; col++) {
                cellImages[row][col] = new Image(Map.MAP_NUMBER_ONE.getACell(row,col).getTexture().getImageAddress());
                ImageView imageView = new ImageView(cellImages[row][col]);

                // Set any additional properties for the ImageView (e.g., size, fit)

                imageView.setFitWidth(cellWidth);

                imageView.setFitHeight(cellHeight);

                // Add the ImageView to the GridPane
                gridPane.add(imageView, col-(startCol), row-(startRow));
            }
        }
        scrollPane.requestLayout();
        gridPane.layout();
    }
    public static void main(String[] args) {
        launch(args);
    }
}